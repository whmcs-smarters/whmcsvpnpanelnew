<!---start footer content-->
<div class="footer">
   <div class="col-lg-2 cl-md-2 col-sm-2"></div>
    <div class="col-lg-8 cl-md-8 col-sm-8 col-xs-12">
        <p>   
            Copyright &copy; 2012 - <?php echo date("Y");?> <?php echo $title;?>. All Rights Reserved. 
        </p>
    </div>
   <div class="col-lg-2 cl-md-2 col-sm-2"></div>
</div>
            <!---end footer content--->


<script type="text/javascript">
            $(document).ready(function () {
                $('[data-toggle="popover"]').popover({
                    placement: 'top',
                    trigger: 'hover'
                });
            });
</script>

<script src="js/bootstrap.min.js"></script>