<?php

include_once("../../../../../init.php");
if (isset($_POST['session']) && $_POST['session'] == 'destroy') {
    unset($_SESSION['uid'], $_SESSION['upw']);
    exit;
}

if (isset($_POST['session']) && $_POST['session'] == 'create') {
    if ($_POST['login'] == 'reseller') {
        if ($_POST['clientid'] != $_SESSION['uid']) {
            $_SESSION['uid'] = $_SESSION['xtreamuserid'];
            $_SESSION['upw'] = $_SESSION['xtreampasswordhash'];
            echo 'yes';
            exit;
        }
        exit;
    } elseif ($_POST['login'] == 'client') {
        if ($_POST['clientid'] != $_SESSION['uid']) {
            $_SESSION['uid'] = $_SESSION['ClientUserid'];
            $_SESSION['upw'] = $_SESSION['ClientPasswordhash'];
            echo 'yes';
            exit;
        }
        exit;
    }
    exit;
}
