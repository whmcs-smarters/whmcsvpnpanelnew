<?php

include_once("../../../../../init.php");

use WHMCS\Database\Capsule;

if (isset($_POST['session']) && $_POST['session'] == 'loginagain') {
    $_SESSION['uid'] = $_POST['clientid'];
    $_SESSION['upw'] = $_POST['loginhashpass'];
    $_SESSION['xtreamuserid'] = $_POST['clientid'];
    $_SESSION['xtreampasswordhash'] = $_POST['loginhashpass'];
    echo 'yes';
    exit;
}
if (isset($_POST['session']) && $_POST['session'] == 'Changextreamuserid') {
    $GetUserGruopType = Capsule::table('tblclients')
            ->join('tblclientgroups', 'tblclients.groupid', '=', 'tblclientgroups.id')
            ->where('tblclients.id', $_POST['clientid'])
            ->select('tblclientgroups.groupname')
            ->get();
    if (!empty($GetUserGruopType)) {
        $_SESSION['xtreamuserid'] = $_POST['clientid'];
        $_SESSION['xtreampasswordhash'] = $_POST['loginhashpass'];
        $_SESSION['uid'] = $_POST['clientid'];
        $_SESSION['upw'] = $_POST['loginhashpass'];
        echo 'yes';
        exit;
    } else {
        echo "no";
        exit;
    }
}
?>