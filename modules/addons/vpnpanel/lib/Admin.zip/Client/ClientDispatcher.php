<?php 
 

use WHMCS\Database\Capsule;

/**
 * Sample Client Area Dispatch Handler
 */
class ClientDispatcher {

    /**
     * Dispatch request.
     *
     * @param string $action
     * @param array $parameters
     *
     * @return array
     */
    public function dispatch($action, $parameters, $zip) { 
 
        
        if (!$action) {
            // Default to index if no action specified
            $action = 'index';
        }
        $controller = new VPNController();

        // Verify requested action is valid and callable
        if (is_callable(array($controller, $action))) { 
         $parameters['zip'] = $zip;
            return $controller->$action($parameters);
        }
    }

}
